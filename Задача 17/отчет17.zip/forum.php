<?php
require "db.php";


$data = $_POST;
if(isset($data['change']))
{
    $errors = array();

    if ($data['post_id'] == '') {
         $errors[] = 'Введите Post ID';

    }elseif ($data['changedtext'] == '') {
         $errors[] = 'Введите текст для замены';
     }else
     {
    

        $post_id = R::findOne('userposts', 'id = ?', array($data['post_id']));
        if($post_id)
        {
            if ($post_id->id = $data['post_id']) {
                $post_id->user_post = $data['changedtext']; 
                    R::store($post_id);
            }

        }else
        {
            $errors[] = 'Сообщения с таким ID не существует';
        }
        

}
    

if ( ! empty ($errors))
        {

         echo '<div style="color: red;">'. array_shift($errors).'</div><hr>';
}
}
//////////////////////////////////////////////////////////////
if(isset($data['delete']))
{
    $errors = array();

    if ($data['post_id'] == '') {
         $errors[] = 'Введите Post ID';

    }else 
     {
        $post_del = R::findOne('userposts', 'id = ?', array($data['post_id']));
        if($post_del)
        {
            if ($post_del->id = $data['post_id']) {
                $post_del->user_post = 'Сообщение удалено'; 
                    R::store($post_del);
            }

        }else
        {
            $errors[] = 'Сообщения с таким ID не существует';
        }
        

}
    

if ( ! empty ($errors))
        {

         echo '<div style="color: red;">'. array_shift($errors).'</div><hr>';
}
}
/////////////////////////////////////////////////////////////////////
$errors = array();

     if (isset($data['do_post']))
    {
   if ($data['user_text'] == '') {

         $errors[] = 'Введите текст поста';

    }elseif ($_SESSION ['logged_user'])
{
        $user_post = R::dispense('userposts');
        $user_post->user_post = $data['user_text'];
        $user_post->nick = $_SESSION ['logged_user']->nick;
        $user_post->dor = date("d/m/Y");
        R::store($user_post); 
        header('Location: forum.php');
    }else
    {
        $errors[] = 'Вы не авторизованы на сайте!';
    }

    if ( ! empty ($errors))
        {

         echo '<div style="color: red;">'. array_shift($errors).'</div><hr>';
}
    }
$allUsersPosts = R::findAll('userposts');
?>
<?if(isset ($_SESSION ['logged_user']) and ($_SESSION ['logged_user']->role=='admin') ) : ?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Форум</title>
    <link rel="stylesheet" href="/assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400,700">
    <link rel="stylesheet" href="/assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="/assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="/assets/css/Footer-Dark.css">
    <link rel="stylesheet" href="/assets/css/Header-Dark.css">
    <link rel="stylesheet" href="/assets/css/styles.css">
</head>

<body>
    <div>
        <div class="header-dark">
            <nav class="navbar navbar-dark navbar-expand-lg navigation-clean-search">

             <?php echo $_SESSION['logged_user']->nick ?>

                <div class="container"><a class="navbar-brand" href="main.php">RTKforum</a><button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse"
                        id="navcol-1">
                        <ul class="nav navbar-nav">
                             <li class="nav-item dropdown"><a class="dropdown-toggle nav-link" data-toggle="dropdown" aria-expanded="false" href="">Написать</a><div class="dropdown-menu" role="menu"><form action="forum2.php" method="POST">
  <div class="form-group" color>
    <input class="form-control" type="Text" name="user_text" placeholder="Text" value="<?php echo @$data['user_text']; ?>">
        <button name="do_post" class="btn btn-primary btn-block" type="submit" style="background-color: rgb(7,7,7);">Запостить</button>
  </div>
</form></div>
                            <li class="nav-item dropdown"><a class="dropdown-toggle nav-link" data-toggle="dropdown" aria-expanded="false" href="#">Еще</a>
                                <div class="dropdown-menu" role="menu"><a class="dropdown-item" role="presentation" href="control panel 1.php">Админ панель</a><a class="dropdown-item" role="presentation" href="control panel 2.php">Информация о пользователях</a></div>
                            </li>
                        </ul>
                        <form class="form-inline mr-auto" target="_self">
                            <div class="form-group"><label for="search-field"><i class="fa fa-search"></i></label><input class="form-control search-field" type="search" id="search-field" name="search"></div>
                        </form><span class="navbar-text"></span><a class="btn btn-light action-button" role="button" href="logout.php">Выйти</a></div>
                </div>
            </nav>
        </div>
    </div>
    <div class="container">
                        <div class="table-responsive table mt-2" id="dataTable" role="grid" aria-describedby="dataTable_info">
                            <table class="table dataTable my-0" id="dataTable">
                                <thead>
                                    <tr>
                                        <th>Nickname</th>
                                        <th><div class="dropdown">
  <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Post
  </button>
  <div class="dropdown-menu">
  <form class="px-4 py-3" method="POST" action="forum.php">
    <div class="form-group">
      <input name="post_id" type="text" class="form-control"  placeholder="Post_id">
      <input name="changedtext" type="text" class="form-control" >
    </div>
    <button name="change" type="submit" class="btn btn-primary">Change</button>
    <button name="delete" type="submit" class="btn btn-primary">Delete</button>
</div>
</form>
</div></th>
                                        <th>DOR</th>
                                        <th>Post_id</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($allUsersPosts as $userposts): ?>
                                    <tr>
                                        
                                        <td><?= $userposts['nick'] ?></td>
                                        <td><?= $userposts['user_post'] ?></td>
                                        <td><?= $userposts['dor'] ?></td>
                                        <td><?= $userposts['id'] ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                               
                            </table>
                        </div>
                        <div class="row">
                            <div class="col-md-6 align-self-center">
                                <p id="dataTable_info" class="dataTables_info" role="status" aria-live="polite">Показано 1 до 10 из 27</p>
                            </div>
                            <div class="col-md-6">
                                <nav class="d-lg-flex justify-content-lg-end dataTables_paginate paging_simple_numbers">
                                    <ul class="pagination">
                                        <li class="page-item disabled"><a class="page-link" href="#" aria-label="Previous"><span aria-hidden="true">«</span></a></li>
                                        <li class="page-item active"><a class="page-link" href="">1</a></li>
                                        <li class="page-item"><a class="page-link" href="">2</a></li>
                                        <li class="page-item"><a class="page-link" href="">3</a></li>
                                        <li class="page-item"><a class="page-link" href="" aria-label="Next"><span aria-hidden="true">»</span></a></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
    <div class="footer-dark">
        <footer>

            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-3 item">
                        <h3>Услуги</h3>
                        <ul>
                            <li><a href="#">Web design</a></li>
                            <li><a href="#">Development</a></li>
                            <li><a href="#">Hosting</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-md-3 item">
                        <h3>О нас</h3>
                        <ul>
                            <li><a href="#">Company</a></li>
                            <li><a href="#">Team</a></li>
                            <li><a href="#">Careers</a></li>
                        </ul>
                    </div>
                    <div class="col-md-6 item text">
                        <h3>RTKforum</h3>
                        <p>Сегодня Радиотехнический колледж расположен на Васильевском острове в новом здании, оборудованном по последнему слову техники. Колледж оснащен современными компьютерами, лабораториями, кабинетами и мастерскими с мультимедийными установками и интерактивными досками, спортивным, тренажерным и актовым залами.
Выпускники радиотехнического колледжа получают диплом государственного образца о среднем профессиональном и среднем общем образовании.</p>
                    </div>
                    <div class="col item social"><a href=""><i class="icon ion-social-facebook"></i></a><a href=""><i class="icon ion-social-twitter"></i></a><a href=""><i class="icon ion-social-snapchat"></i></a><a href="https://www.instagram.com/kolledz_rtk/"><i class="icon ion-social-instagram"></i></a></div>
                </div>
                <p class="copyright">RTKforum © 2020</p>
            </div>
        </footer>
    </div>
    <script src="/assets/js/jquery.min.js"></script>
    <script src="/assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>

<? elseif(isset ($_SESSION ['logged_user']) and ($_SESSION ['logged_user']->role=='user') or ($_SESSION ['logged_user']->role=='ILLEGAL') ) : ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Форум</title>
    <link rel="stylesheet" href="/assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400,700">
    <link rel="stylesheet" href="/assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="/assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="/assets/css/Footer-Dark.css">
    <link rel="stylesheet" href="/assets/css/Header-Dark.css">
    <link rel="stylesheet" href="/assets/css/styles.css">
</head>

<body>
    <div>
        <div class="header-dark">
            <nav class="navbar navbar-dark navbar-expand-lg navigation-clean-search">

             <?php echo $_SESSION['logged_user']->nick ?>

                <div class="container"><a class="navbar-brand" href="main.php">RTKforum</a><button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse"
                        id="navcol-1">
                        <ul class="nav navbar-nav">

                            <li class="nav-item dropdown"><a class="dropdown-toggle nav-link" data-toggle="dropdown" aria-expanded="false" href="">Написать</a><div class="dropdown-menu" role="menu"><form action="forum2.php" method="POST">
  <div class="form-group" color>
    <input class="form-control" type="Text" name="user_text" placeholder="Text" value="<?php echo @$data['user_text']; ?>">
        <button name="do_post" class="btn btn-primary btn-block" type="submit" style="background-color: rgb(7,7,7);">Запостить</button>
  </div>
</form></div>
                            <li class="nav-item dropdown"><a class="dropdown-toggle nav-link" data-toggle="dropdown" aria-expanded="false" href="">Еще</a>
                                <div class="dropdown-menu" role="menu"><a class="dropdown-item" role="presentation" href="">First Item</a><a class="dropdown-item" role="presentation" href="">Second Item</a><a class="dropdown-item" role="presentation" href="">Third Item</a></div>
                            </li>
                        </ul>
                        <form class="form-inline mr-auto" target="_self">
                            <div class="form-group"><label for="search-field"><i class="fa fa-search"></i></label><input class="form-control search-field" type="search" id="search-field" name="search"></div>
                        </form><span class="navbar-text"></span><a class="btn btn-light action-button" role="button" href="logout.php">Выйти</a></div>
                </div>
            </nav>
        </div>
                            </div>
         <div class="container">
        <?php foreach ($allUsersPosts as $userposts): ?>
        <div class="border rounded-0 shadow">
            <div class="row">
                <div class="col">
                    <h1>&nbsp;&nbsp;<?= $userposts['nick'] ?></h1><span>&nbsp;<?= $userposts['dor'] ?></span></div>
                <div class="col-lg-8 item text">
                    <p><?= $userposts['user_post'] ?><br></p>
                </div>
            </div>
        </div>
        <br>
    <? endforeach ; ?>
    </div>
    <div class="footer-dark">
        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-3 item">
                        <h3>Услуги</h3>
                        <ul>
                            <li><a href="#">Web design</a></li>
                            <li><a href="#">Development</a></li>
                            <li><a href="#">Hosting</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-md-3 item">
                        <h3>О нас</h3>
                        <ul>
                            <li><a href="#">Company</a></li>
                            <li><a href="#">Team</a></li>
                            <li><a href="#">Careers</a></li>
                        </ul>
                    </div>
                    <div class="col-md-6 item text">
                        <h3>RTKforum</h3>
                        <p>Сегодня Радиотехнический колледж расположен на Васильевском острове в новом здании, оборудованном по последнему слову техники. Колледж оснащен современными компьютерами, лабораториями, кабинетами и мастерскими с мультимедийными установками и интерактивными досками, спортивным, тренажерным и актовым залами.
Выпускники радиотехнического колледжа получают диплом государственного образца о среднем профессиональном и среднем общем образовании.</p>
                    </div>
                    <div class="col item social"><a href="#"><i class="icon ion-social-facebook"></i></a><a href="#"><i class="icon ion-social-twitter"></i></a><a href="#"><i class="icon ion-social-snapchat"></i></a><a href="#"><i class="icon ion-social-instagram"></i></a></div>
                </div>
                <p class="copyright">RTKforum © 2020</p>
            </div>
        </footer>
    </div>
    <script src="/assets/js/jquery.min.js"></script>
    <script src="/assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>
<? else :?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Форум</title>
    <link rel="stylesheet" href="/assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400,700">
    <link rel="stylesheet" href="/assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="/assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="/assets/css/Footer-Dark.css">
    <link rel="stylesheet" href="/assets/css/Header-Dark.css">
    <link rel="stylesheet" href="/assets/css/styles.css">
</head>

<body>
    <div>
        <div class="header-dark">
            <nav class="navbar navbar-dark navbar-expand-lg navigation-clean-search">

             <?php echo $_SESSION['logged_user']->nick ?>

                <div class="container"><a class="navbar-brand" href="main.php">RTKforum</a><button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse"
                        id="navcol-1">
                        <ul class="nav navbar-nav">

                            <li class="nav-item dropdown"><a class="dropdown-toggle nav-link" data-toggle="dropdown" aria-expanded="false" href="">Написать</a><div class="dropdown-menu" role="menu"><form action="forum.php" method="POST">
  <div class="form-group" color>
    <input class="form-control" type="Text" name="user_text" placeholder="Text" value="<?php echo @$data['user_text']; ?>">
        <button name="do_post" class="btn btn-primary btn-block" type="submit" style="background-color: rgb(7,7,7);">Запостить</button>
  </div>
</form></div>
                            <li class="nav-item dropdown"><a class="dropdown-toggle nav-link" data-toggle="dropdown" aria-expanded="false" href="">Еще</a>
                                <div class="dropdown-menu" role="menu"><a class="dropdown-item" role="presentation" href="">First Item</a><a class="dropdown-item" role="presentation" href="">Second Item</a><a class="dropdown-item" role="presentation" href="">Third Item</a></div>
                            </li>
                        </ul>
                        <form class="form-inline mr-auto" target="_self">
                            <div class="form-group"><label for="search-field"><i class="fa fa-search"></i></label><input class="form-control search-field" type="search" id="search-field" name="search"></div>
                        </form><span class="navbar-text"><a class="login" href="form sign up.php">Зарегистрироваться</a></span><a class="btn btn-light action-button" role="button" href="form sign in.php">Войти</a></div>
                </div>
            </nav>
        </div>
                            </div>
         <div class="container">
        <?php foreach ($allUsersPosts as $userposts): ?>
        <div class="border rounded-0 shadow">
            <div class="row">
                <div class="col">
                    <h1>&nbsp;&nbsp;<?= $userposts['nick'] ?></h1><span>&nbsp;<?= $userposts['dor'] ?></span></div>
                <div class="col-lg-8 item text">
                    <p><?= $userposts['user_post'] ?><br></p>
                </div>
            </div>
        </div>
        <br>
    <? endforeach ; ?>
    </div>
    <div class="footer-dark">
        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-3 item">
                        <h3>Услуги</h3>
                        <ul>
                            <li><a href="#">Web design</a></li>
                            <li><a href="#">Development</a></li>
                            <li><a href="#">Hosting</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-md-3 item">
                        <h3>О нас</h3>
                        <ul>
                            <li><a href="#">Company</a></li>
                            <li><a href="#">Team</a></li>
                            <li><a href="#">Careers</a></li>
                        </ul>
                    </div>
                    <div class="col-md-6 item text">
                        <h3>RTKforum</h3>
                        <p>Сегодня Радиотехнический колледж расположен на Васильевском острове в новом здании, оборудованном по последнему слову техники. Колледж оснащен современными компьютерами, лабораториями, кабинетами и мастерскими с мультимедийными установками и интерактивными досками, спортивным, тренажерным и актовым залами.
Выпускники радиотехнического колледжа получают диплом государственного образца о среднем профессиональном и среднем общем образовании.</p>
                    </div>
                    <div class="col item social"><a href="#"><i class="icon ion-social-facebook"></i></a><a href="#"><i class="icon ion-social-twitter"></i></a><a href="#"><i class="icon ion-social-snapchat"></i></a><a href="#"><i class="icon ion-social-instagram"></i></a></div>
                </div>
                <p class="copyright">RTKforum © 2020</p>
            </div>
        </footer>
    </div>
    <script src="/assets/js/jquery.min.js"></script>
    <script src="/assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>
<? endif ;?>