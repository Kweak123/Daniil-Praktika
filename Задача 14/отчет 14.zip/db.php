<?php

require "libs/rb.php";
R::setup( 'mysql:host=localhost;dbname=rtk_forum',
        'root', '' );

session_start();


//if ( $_SESSION['auth'] == true and $_SESSION['status'] == 10) {	} 
