<?php

require "libs/rb.php";
R::setup( 'mysql:host=localhost;dbname=rtk_forum',
        'root', '' );

session_start();