<?php
require "db.php";

$data = $_POST;
    if (isset ($data['do_signin']))
    {
        $errors = array();
       $user = R::findOne('users', 'email = ?', array($data['email']));
        if ($user)
        {
            if (password_verify($data['password'], $user->password))
            {
                
               $_SESSION['logged_user'] = $user; 
                 if ($_SESSION['logged_user']->role=='user')
                {
                header('Location: /main.php'); 

                }elseif($_SESSION['logged_user']->role=='admin')
                {
                header('Location: /control panel 1.php');
                
                
                }else
                {
                    $errors[] = 'Незаконный';
                }
                
            }else
            {
                $errors[] = 'Неверно введен пароль';
            }
        }else 
        {
            $errors[] = 'Пользователь с таким email не найден';
        }
         if ( ! empty ($errors))
    {

     echo '<div style="color: red;">'. array_shift($errors).'</div><hr>';


    }
}
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Форма регистрации</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400,700">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/Footer-Dark.css">
    <link rel="stylesheet" href="assets/css/Header-Dark.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Dark.css">
    <link rel="stylesheet" href="assets/css/Registration-Form-with-Photo.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <div>
        <div class="header-dark" style="height: 300px;">
            <nav class="navbar navbar-dark navbar-expand-lg navigation-clean-search">
                <div class="container"><a class="navbar-brand" href="main.php">RTKforum</a><button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse"
                        id="navcol-1">
                        <ul class="nav navbar-nav">
                            <li class="nav-item" role="presentation"><a class="nav-link" href="#">Форум</a></li>
                            <li class="nav-item dropdown"><a class="dropdown-toggle nav-link" data-toggle="dropdown" aria-expanded="false" href="#">Еще&nbsp;</a>
                                <div class="dropdown-menu" role="menu"><a class="dropdown-item" role="presentation" href="#">First Item</a><a class="dropdown-item" role="presentation" href="#">Second Item</a><a class="dropdown-item" role="presentation" href="#">Third Item</a></div>
                            </li>
                        </ul>
                        <form class="form-inline mr-auto" target="_self">
                            <div class="form-group"><label for="search-field"><i class="fa fa-search"></i></label><input class="form-control search-field" type="search" id="search-field" name="search"></div>
                        </form><span class="navbar-text"><a class="login" href="form sign up.php">Регистрация</a></span></div>
                </div>
            </nav>
            <div class="container hero">
                <div class="row">
                    <div class="col-md-8 offset-md-2">
                        <h1 class="text-center">Место для дискуссий</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="register-photo" style="background-color: rgb(68,68,68);">
        <div class="form-container">
            <form action="form sign in.php" method="post">
                <h2 class="text-center"><strong>Войти</strong></h2>
                <div class="form-group"><input class="form-control" type="email" name="email" placeholder="Email" value="<?php echo @$data['email']; ?>"></div>
                <div class="form-group"><input class="form-control" type="password" name="password" placeholder="Password" value="<?php echo @$data['password']; ?>"></div>
                <div class="form-group"><button name="do_signin" class="btn btn-primary btn-block" type="submit" style="background-color: rgb(0,0,0);">Войти</button></div>
        </div>
    </div>
    <div class="footer-dark" style="background-image: url(&quot;assets/img/mountain_bg.jpg&quot;);">
        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-3 item">
                        <h3>Услуги</h3>
                        <ul>
                            <li><a href="#">Web design</a></li>
                            <li><a href="#">Development</a></li>
                            <li><a href="#">Hosting</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-md-3 item">
                        <h3>О нас</h3>
                        <ul>
                            <li><a href="#">Company</a></li>
                            <li><a href="#">Team</a></li>
                            <li><a href="#">Careers</a></li>
                        </ul>
                    </div>
                    <div class="col-md-6 item text">
                        <h3>RTKforum</h3>
                        <p>Сегодня Радиотехнический колледж расположен на Васильевском острове в новом здании, оборудованном по последнему слову техники. Колледж оснащен современными компьютерами, лабораториями, кабинетами и мастерскими с мультимедийными установками и интерактивными досками, спортивным, тренажерным и актовым залами.
Выпускники радиотехнического колледжа получают диплом государственного образца о среднем профессиональном и среднем общем образовании.</p>
                    </div>
                    <div class="col item social"><a href="#"><i class="icon ion-social-facebook"></i></a><a href="#"><i class="icon ion-social-twitter"></i></a><a href="#"><i class="icon ion-social-snapchat"></i></a><a href="#"><i class="icon ion-social-instagram"></i></a></div>
                </div>
                <p class="copyright">RTKforum © 2020</p>
            </div>
        </footer>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>