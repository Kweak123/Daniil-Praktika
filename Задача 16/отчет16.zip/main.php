<?php
require "db.php";
?>

<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Главная страница</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400,700">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/Footer-Dark.css">
    <link rel="stylesheet" href="assets/css/Header-Dark.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <div>
        <div class="header-dark" style="height: 550px;">
            <nav class="navbar navbar-dark navbar-expand-lg navigation-clean-search">

                <?php echo $_SESSION['logged_user']->nick ?>

                <div class="container"><a class="navbar-brand" >RTKforum</a><button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse"
                        id="navcol-1">
                        <ul class="nav navbar-nav">
                            <li class="nav-item" role="presentation"><a class="nav-link" href="forum.php">Форум</a></li>

                            <?if(isset ($_SESSION ['logged_user']) and ($_SESSION ['logged_user']->role=='user') ) : ?>

                            <li class="nav-item dropdown"><a class="dropdown-toggle nav-link" data-toggle="dropdown" aria-expanded="false" href="#">Еще</a>
                                <div class="dropdown-menu" role="menu"><a class="dropdown-item" role="presentation" href="forum.php">First Item</a><a class="dropdown-item" role="presentation" href="#">Second Item</a><a class="dropdown-item" role="presentation" href="#">Third Item</a></div>
                            </li>
                            <? elseif($_SESSION ['logged_user']->role=='admin') :?>
                            <li class="nav-item dropdown"><a class="dropdown-toggle nav-link" data-toggle="dropdown" aria-expanded="false" href="#">Еще</a>
                                <div class="dropdown-menu" role="menu"><a class="dropdown-item" role="presentation" href="control panel 1.php">Админ панель</a><a class="dropdown-item" role="presentation" href="control panel 2.php">Информация о пользователях</a></div>
                            </li>
                            <? else:?>
                            <li class="nav-item dropdown"><a class="dropdown-toggle nav-link" data-toggle="dropdown" aria-expanded="false" href="#">Еще</a>
                                <div class="dropdown-menu" role="menu"><a class="dropdown-item" role="presentation" href="">First Item</a><a class="dropdown-item" role="presentation" href="">Second Item</a><a class="dropdown-item" role="presentation" href="">Third Item</a></div>
                            </li>
                            <? endif?>

                        </ul>

                        <? if (isset ($_SESSION ['logged_user']) == false) :?>

                        <form class="form-inline mr-auto" target="_self">
                            <div class="form-group"><label for="search-field"><i class="fa fa-search"></i></label><input class="form-control search-field" type="search" id="search-field" name="search"></div>
                        </form><span class="navbar-text"><a class="login" href="form sign up.php">Зарегистрироваться</a></span><a class="btn btn-light action-button" role="button" href="form sign in.php">Войти</a>
                        <? else:?>
                        <form class="form-inline mr-auto" target="_self">
                            <div class="form-group"><label for="search-field"><i class="fa fa-search"></i></label><input class="form-control search-field" type="search" id="search-field" name="search"></div>
                        </form>
                        <a class="btn btn-light action-button" role="button" href="logout.php">Выйти</a>

                        <? endif?>

                    </div>
                </div>
            </nav>
            <div class="container hero">
                <div class="row">
                    <div class="col-md-8 offset-md-2">
                        <h1 class="text-center">Место для дискуссий</h1>
                    </div>
                </div>
            </div>
            <h3 class="text-center text-light"><br>На этом форуме вы можете делиться своими мыслями с другими людьми, получать ответы на интересующие вас вопросы и многое другое<br><br></h3>
            <h1></h1>
        </div>
    </div>
    <div class="footer-dark" style="height: 450px;">
        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-3 item">
                        <h3>Услуги</h3>
                        <ul>
                            <li><a href="#">Web design</a></li>
                            <li><a href="#">Development</a></li>
                            <li><a href="#">Hosting</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-md-3 item">
                        <h3>О нас</h3>
                        <ul>
                            <li><a href="#">Company</a></li>
                            <li><a href="#">Team</a></li>
                            <li><a href="#">Careers</a></li>
                        </ul>
                    </div>
                    <div class="col-md-6 item text">
                        <h3>RTKforum</h3>
                        <p>Сегодня Радиотехнический колледж расположен на Васильевском острове в новом здании, оборудованном по последнему слову техники. Колледж оснащен современными компьютерами, лабораториями, кабинетами и мастерскими с мультимедийными установками и интерактивными досками, спортивным, тренажерным и актовым залами.
Выпускники радиотехнического колледжа получают диплом государственного образца о среднем профессиональном и среднем общем образовании.</p>
                    </div>
                    <div class="col item social"><a href="#"><i class="icon ion-social-facebook"></i></a><a href="#"><i class="icon ion-social-twitter"></i></a><a href="#"><i class="icon ion-social-snapchat"></i></a><a href="https://www.instagram.com/kolledz_rtk/"><i class="icon ion-social-instagram"></i></a></div>
                </div>
                <p class="copyright">RTKforum © 2020</p>
            </div>
        </footer>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>
