-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Июл 15 2020 г., 20:29
-- Версия сервера: 10.3.13-MariaDB
-- Версия PHP: 7.1.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `rtk_forum`
--

-- --------------------------------------------------------

--
-- Структура таблицы `userposts`
--

CREATE TABLE `userposts` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_post` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nick` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dor` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `userposts`
--

INSERT INTO `userposts` (`id`, `user_post`, `nick`, `dor`) VALUES
(10, '123454566', 'user2', '14/07/2020'),
(11, 'sdr;lh,sfl;gh;dlgk;ld', 'user3', '14/07/2020'),
(12, 'xfghdfghdfghdfghd', 'lex', '14/07/2020'),
(13, 'dfyjdghjfghjf', 'Dan', '14/07/2020'),
(14, 'fcfkfvvfktqrev', 'Max', '14/07/2020'),
(15, 'ты лох обоссаный', 'Max', '14/07/2020'),
(16, 'dfhfgjhdgfhjdgz', 'user2', '14/07/2020'),
(17, 'sdgdsg', 'user2', '14/07/2020'),
(18, 'законный', 'user2', '14/07/2020'),
(19, 'авыа', 'user2', '14/07/2020'),
(20, 'rrrrrrr', 'user2', '14/07/2020'),
(21, 'ggggggg', 'user2', '14/07/2020');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `nick` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dor` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `nick`, `email`, `password`, `role`, `dor`) VALUES
(24, 'user2', 'user2@gmail.com', '$2y$10$1.JuMccAYA.JwyRmrNgRQu9vwk5oZL/JUkE41GEVghg57r5T7Dtum', 'user', '10/07/2020'),
(25, 'user', 'user@gmail.com', '$2y$10$i3VXUP4GntEOv08FAsTPtuHkufMwoErjeKA..hqtV0ZYAo27Q6MdG', 'user', '10/07/2020'),
(26, 'admin', 'admin@gmail.com', '$2y$10$AMUXx6nYY/JnA1/MtMoTneSLdfmOgMEl91vTxqgK/q7QFM2l7ZM0W', 'admin', '10/07/2020'),
(27, 'user3', 'user3@gmail.com', '$2y$10$gfJs.PLgRAPYXN.PPzjpLeHql3eYNMthyvZ/nWGvosSPkhgU0j.9C', 'user', '10/07/2020'),
(28, 'admin2', 'admin2@gmail.com', '$2y$10$CpGnGHT4jcQz32YHPv8am.vtuZne074qN86aO05eetfh6oLvO7xU6', 'admin', '10/07/2020'),
(29, 'lex', 'userlex@gmail.com', '$2y$10$/MQFg2Ad7Dq9ARSzfRY8vuwACifTM3ykt8a3AuqXh1dffWr2menBK', 'admin', '10/07/2020'),
(30, 'Max', 'Max@gmail.com', '$2y$10$AqDpvExZofjV4v2RAAqEyuAYjmVE.O.LpLOPgGuDRyv4D8xReGpMa', 'user', '12/07/2020'),
(31, 'Dan', 'Dan@gmail.com', '$2y$10$GtzuGG0VvVnbdcu.KdqQse6tU9GWmo577KtBMxRJU/9hDouNBGSlC', 'admin', '12/07/2020'),
(32, 'Maria', 'Maria@gmail.com', '$2y$10$qmkdJQ7fpN64pumWIjlbg.eal/nOmDHaMgqRlAqq9m1Ba0E/w.IE6', 'user', '12/07/2020'),
(33, 'Sanya', 'Sanya@gmail.com', '$2y$10$ojoaHo0WL4Ekg/h6hiidI.JxM6CCs9Uv9D/IMElj0Gulh98cQRTga', 'user', '12/07/2020');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `userposts`
--
ALTER TABLE `userposts`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `userposts`
--
ALTER TABLE `userposts`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
